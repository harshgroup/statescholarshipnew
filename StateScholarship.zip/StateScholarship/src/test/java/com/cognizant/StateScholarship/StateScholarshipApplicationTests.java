package com.cognizant.StateScholarship;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StateScholarshipApplicationTests {

	@Test
	void contextLoads() {
	}

}
