package com.cognizant.service;

import org.eclipse.jdt.internal.compiler.ast.ModuleDeclaration;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

@ControllerAdvice
public class ControllerAdvisor  {

    @ExceptionHandler(Exception.class)
    public ModelAndView  handleCityNotFoundException(
       Exception ex) {
ModelAndView mv=new ModelAndView();
       mv.addObject("errormsg", ex.getMessage());
       mv.setViewName("login");

        return mv;
    }
}