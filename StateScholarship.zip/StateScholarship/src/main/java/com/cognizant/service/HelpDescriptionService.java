package com.cognizant.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.dto.HelpUserDto;
import com.cognizant.model.HelpDescription;
import com.cognizant.repository.HelpDescriptionRepository;

@Service
public class HelpDescriptionService {
	@Autowired
	HelpDescriptionRepository helpDescriptionRepository;

	public void saveDescription(HelpDescription helpDescription) {
		helpDescriptionRepository.save(helpDescription);
	}

	public List<HelpDescription> fetchDescriptions(int userId) {
		// TODO Auto-generated method stub
		return helpDescriptionRepository.getAllDescriptionsBasedOnUserId(userId);
	}
	public List<HelpDescription> fetchDescriptions(int userId,String status) {
		// TODO Auto-generated method stub
		return helpDescriptionRepository.getAllDescriptionsBasedOnUserIdAndStatus(userId,status);
	}

	public HelpDescription fetchDescription(String descriptionId) {
		Optional<HelpDescription> oph = helpDescriptionRepository.findById(Integer.parseInt(descriptionId));
		if (oph.isPresent()) {
			return oph.get();
		} else {
			return null;
		}

	}

	public List<HelpUserDto> fetchUserIds(String status) {
		return helpDescriptionRepository.getUserIdsBasedOnStatus(status);
	}

	public void updateStatus(int descriptionId, String string) {
		// TODO Auto-generated method stub
		helpDescriptionRepository.updateStatusByDescriptionId(descriptionId,string);
	}

	public void updateSolution(int descriptionId, String solution) {
		// TODO Auto-generated method stub
		helpDescriptionRepository.updateSolutionByDescriptionId(descriptionId,solution);
	}

	public List<HelpDescription> fetchDescriptions(String status) {
		// TODO Auto-generated method stub
		return helpDescriptionRepository.getDescriptionsBasedOnStatus(status);
	}
}
