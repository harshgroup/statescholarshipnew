package com.cognizant.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.model.ScholarshipForm;
import com.cognizant.repository.ScholarshipFormRepository;

@Service
public class ScholarshipFormService {
	@Autowired
	ScholarshipFormRepository scholarshipFormRepository;

	public ScholarshipForm fetchForm(int userId) {
		return scholarshipFormRepository.getFormByUserId(userId);
	}
	
	public ScholarshipForm fetchFormByFormId(int formId) {
		Optional<ScholarshipForm> ops = scholarshipFormRepository.findById(formId);
		if(ops.isPresent()) {
			return ops.get();
		} else {
			return null;
		}
	}
	
	public void saveForm(ScholarshipForm scholarshipForm) {
		scholarshipFormRepository.save(scholarshipForm);

	}

	public int fetchUserId(int approvedBy) {
		return scholarshipFormRepository.getUserIdBasedOnApprovedBy(approvedBy);
	}

	public List<ScholarshipForm> fetchAllRequests(String status) {
		return scholarshipFormRepository.getAllFormsBasedOnStatus(status);
	}

	public void updateStatus(String status, int formId) {
		// TODO Auto-generated method stub
		scholarshipFormRepository.updateStatusByRequestId(status, formId);
		
	}

	public void updateApprovedBy(int userId, int formId) {
		// TODO Auto-generated method stub
		scholarshipFormRepository.updateApprovedByFormId(userId, formId);
	}
}
