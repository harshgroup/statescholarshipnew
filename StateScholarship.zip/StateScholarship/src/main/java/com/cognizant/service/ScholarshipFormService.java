package com.cognizant.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.model.ScholarshipForm;
import com.cognizant.repository.ScholarshipFormRepository;

@Service
public class ScholarshipFormService {
	@Autowired
	ScholarshipFormRepository scholarshipFormRepository;

	public ScholarshipForm fetchForm(int userId) {
		return scholarshipFormRepository.getFormByUserId(userId);
	}

	public void saveForm(ScholarshipForm scholarshipForm) {
		scholarshipFormRepository.save(scholarshipForm);

	}

	public int fetchUserId(int approvedBy) {
		return scholarshipFormRepository.getUserIdBasedOnApprovedBy(approvedBy);
	}
}
