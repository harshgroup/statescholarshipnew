package com.cognizant.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.cognizant.model.User;
import com.cognizant.repository.UserRepository;

@Service
public class UserService {
	@Autowired
	UserRepository userRepository;

	public String fetchUserName(String username) {

		return userRepository.getUserNameOnUserName(username);
	}

	public String fetchPassowrd(String username) {

		return userRepository.getPasswordOnUserName(username);
	}

	public void saveUser(User user) {
		userRepository.save(user);

	}

	public String fetchRole(String username) {
		return userRepository.getRoleByUserName(username);
	}

	public String fetchFirstName(int userId) {
		return userRepository.getFirstNameBasedOnUserId(userId);
	}

	public String fetchLastName(int userId) {
		return userRepository.getLastNameBasedOnUserId(userId);
	}

	public User fetchUser(String username) {
		// TODO Auto-generated method stub
		return userRepository.getUserBasedOnUserName(username);
	}

	public User fetchUser(int userId) {
		Optional<User> opu = userRepository.findById(userId);
		if (opu.isPresent()) {
			return opu.get();
		} else {
			return null;
		}
	}

}
