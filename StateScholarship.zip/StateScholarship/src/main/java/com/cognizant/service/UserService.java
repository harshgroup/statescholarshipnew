package com.cognizant.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.cognizant.model.User;
import com.cognizant.repository.UserRepository;

@Service
public class UserService {
	@Autowired
	UserRepository userRepository;

	public String fetchUserName(String username) {

		return userRepository.getUserNameOnUserName(username);
	}

	public String fetchPassowrd(String username) {

		return userRepository.getPasswordOnUserName(username);
	}

	public void saveUser(User user) {
		userRepository.save(user);

	}

	public String fetchRole(String username) {
		return userRepository.getRoleByUserName(username);
	}

	public String fetchFirstName(int userId) {
		return userRepository.getFirstNameBasedOnUserId(userId);
	}

	public String fetchLastName(int userId) {
		return userRepository.getLastNameBasedOnUserId(userId);
	}

	public User fetchUser(String username) {
		// TODO Auto-generated method stub
		return userRepository.getUserBasedOnUserName(username);
	}

	public User fetchUser(int userId) {
		Optional<User> opu = userRepository.findById(userId);
		if (opu.isPresent()) {
			return opu.get();
		} else {
			return null;
		}
	}

	public String fetchSecurityAns(String userName) {
		// TODO Auto-generated method stub
		return userRepository.getSecurityAnsBasedOnUserName(userName);
	}

	public void updatePassword(String password,String userName) {
		// TODO Auto-generated method stub
		userRepository.updateUserPasswordBasedOnUserName(password,userName);
	}

	public String fetchEmail(String email) {
		// TODO Auto-generated method stub
		 return userRepository.getEmailOnEmail(email);
	}

	public String fetchSecurityAnsByEmail(String email) {
		// TODO Auto-generated method stub
		return userRepository.getSecurityAnsBasedOnEmail(email);
	}
	public String fetchSecurityQueByEmail(String email) {
		// TODO Auto-generated method stub
		return userRepository.getSecurityQueBasedOnEmail(email);
	}


	public String fetchSecurityQue(String userName) {
		// TODO Auto-generated method stub
		return userRepository.getSecurityQueBasedOnUserName(userName);
	}

	public String fetchUserNameOnEmail(String email) {
		// TODO Auto-generated method stub
		return userRepository.getUserNameOnEmail(email);
	}

	

}
