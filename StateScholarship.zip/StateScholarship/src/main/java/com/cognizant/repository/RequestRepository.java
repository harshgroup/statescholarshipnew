package com.cognizant.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cognizant.model.Request;

@Repository
public interface RequestRepository extends JpaRepository<Request, Integer> {
	@Query("select r from Request r where student_id=?1")
	Request findRequestByStudentId(int student_id);
	
	List<Request> findAllRequestsByStatus(String status);
	@Transactional
	@Modifying
	@Query("UPDATE Request r SET r.status= ?1 WHERE r.requestId = ?2")
	public void updateStatusByRequestId(String status, int requestId);
}

