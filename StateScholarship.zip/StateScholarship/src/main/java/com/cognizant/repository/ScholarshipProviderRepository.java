package com.cognizant.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cognizant.model.ScholarshipProvider;
@Repository
public interface ScholarshipProviderRepository extends JpaRepository<ScholarshipProvider,Integer> {
	@Query("select s from ScholarshipProvider s where s.userName=?1 and s.password=?2")
	ScholarshipProvider getScholarshipProviderLoginPassword(String userName, String password);
	
}
	