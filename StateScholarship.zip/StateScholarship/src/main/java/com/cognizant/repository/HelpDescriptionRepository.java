package com.cognizant.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cognizant.dto.HelpUserDto;
import com.cognizant.model.HelpDescription;

@Repository
public interface HelpDescriptionRepository extends JpaRepository<HelpDescription, Integer> {
	@Query("select h from HelpDescription h where h.userId=?1")
	List<HelpDescription> getAllDescriptionsBasedOnUserId(int userId);
	
	
	@Query("select new com.cognizant.dto.HelpUserDto(h.userId,u.firstName,u.lastName) from HelpDescription h inner join User u on h.userId=u.userId where h.status=?1 group by h.userId")
	List<HelpUserDto> getUserIdsBasedOnStatus(String status);
	@Query("select h from HelpDescription h where h.userId=?1 and status=?2")
	List<HelpDescription> getAllDescriptionsBasedOnUserIdAndStatus(int userId, String status);
	@Transactional
	@Modifying
	@Query("UPDATE HelpDescription h SET h.status= ?2 WHERE h.descriptionId = ?1")
	void updateStatusByDescriptionId(int descriptionId, String string);
	@Transactional
	@Modifying
	@Query("UPDATE HelpDescription h SET h.solution= ?2 WHERE h.descriptionId = ?1")
	void updateSolutionByDescriptionId(int descriptionId, String solution);
	@Query("select h from HelpDescription h where h.status=?1")
	List<HelpDescription> getDescriptionsBasedOnStatus(String status);

}
