package com.cognizant.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cognizant.model.ScholarshipForm;

@Repository
public interface ScholarshipFormRepository extends JpaRepository<ScholarshipForm, Integer> {

	ScholarshipForm getFormByUserId(int userId);
	
	@Query("select s.userId from ScholarshipForm s where s.approvedBy=?1")
	int getUserIdBasedOnApprovedBy(int approvedBy);

}