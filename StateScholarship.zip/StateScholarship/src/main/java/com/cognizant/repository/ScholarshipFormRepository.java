package com.cognizant.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cognizant.model.ScholarshipForm;

@Repository
public interface ScholarshipFormRepository extends JpaRepository<ScholarshipForm, Integer> {

	ScholarshipForm getFormByUserId(int userId);

	@Query("select s.userId from ScholarshipForm s where s.approvedBy=?1")
	int getUserIdBasedOnApprovedBy(int approvedBy);
	@Query("select s from ScholarshipForm s where status=?1")
	List<ScholarshipForm> getAllFormsBasedOnStatus(String status);

	@Transactional
	@Modifying
	@Query("UPDATE ScholarshipForm s SET s.status= ?1 WHERE s.formId = ?2")
	public void updateStatusByRequestId(String status, int formId);
	
	@Transactional
	@Modifying
	@Query("UPDATE ScholarshipForm s SET s.approvedBy= ?1 WHERE s.formId = ?2")
	void updateApprovedByFormId(int userId, int formId);

}