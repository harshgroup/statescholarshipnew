package com.cognizant.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cognizant.model.User;

@Repository
public interface UserRepository extends JpaRepository<User, Integer> {
	@Query("select u.userName from User u where u.userName=?1")
	String getUserNameOnUserName(String username);

	@Query("select u.password from User u where u.userName=?1")
	String getPasswordOnUserName(String username);
	
	@Query("select u.role from User u where u.userName=?1")
	String getRoleByUserName(String username);
	
	@Query("select u.firstName from User u where u.userId=?1")
	String getFirstNameBasedOnUserId(int userId);
	
	@Query("select u.lastName from User u where u.userId=?1")
	String getLastNameBasedOnUserId(int userId);
	@Query("select u from User u where u.userName=?1")
	User getUserBasedOnUserName(String userName);


}
