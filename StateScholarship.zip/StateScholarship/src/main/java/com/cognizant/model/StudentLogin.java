package com.cognizant.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.springframework.stereotype.Component;

//@Entity
//@Component
public class StudentLogin {
                
                
                //@Id
                @NotNull(message="Username must be entered")
                @Pattern(regexp="[A-Za-z0-9_]{6,}",message="username should be alphanumeric only and of minimum of 6 charactes")
                private String userName;
                
                @NotNull(message="Password must be entered")
                @Pattern(regexp="(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}",message="Password should be valid characters only and of minimum of 8 charactes")
                private String password;
                
                @NotNull(message="Security question must be entered")
                @Pattern(regexp="^[a-zA-Z\\s]+",message="Security question should be alphabets and ends with ?")
                private String securityQues;
                
                @NotNull(message="Security answer must be entered")
                @Pattern(regexp="^[a-zA-Z\\s]+",message="Security answer should be alphabets only")
                private String securityAns;

                public String getUserName() {
                                return userName;
                }

                public void setUserName(String userName) {
                                this.userName = userName;
                }

                public String getPassword() {
                                return password;
                }

                public void setPassword(String password) {
                                this.password = password;
                }

                public String getSecurityQues() {
                                return securityQues;
                }

                public void setSecurityQues(String securityQues) {
                                this.securityQues = securityQues;
                }

                public String getSecurityAns() {
                                return securityAns;
                }

                public void setSecurityAns(String securityAns) {
                                this.securityAns = securityAns;
                }
                
                
                

                
                

}






