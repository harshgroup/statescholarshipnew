package com.cognizant.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.springframework.stereotype.Component;

import java.sql.Date;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Max;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@Entity
@Component
public class ScholarshipForm {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int formId;

	private int userId;
	@NotEmpty(message = "*Father's name must be entered")
	@Pattern(regexp = "^[A-Za-z\\s]+", message = "*Father's name should be alphabet only")
	@Size(min = 2, message = "*atleast 2 characters are required")
	private String fatherName;

	@NotEmpty(message = "*Mother's name must be entered")
	@Pattern(regexp = "^[A-Za-z\\s]+", message = "*Mother's name should be alphabet only")
	@Size(min = 2, message = "*atleast 2 characters are required")
	private String motherName;

	@NotEmpty(message = "*College must be entered")
	@Pattern(regexp = "^[a-zA-Z\\s]+", message = "*College should be alphabets only")
	private String college;

	@NotNull(message = "*annual marks must be positive value")
	@Max(value = 100, message = "*marks should be less than 100")
	private double annualMarks;

	@NotEmpty(message = "*Father's occupation must be entered")
	@Pattern(regexp = "^[a-zA-Z\\s]+", message = "*Father occupation should be alphabets only")
	private String fatherOccupation;

	@NotEmpty(message = "*Mother's occupation must be entered")
	@Pattern(regexp = "^[a-zA-Z\\s]+", message = "*Mother occupation should be alphabets only")
	private String motherOccupation;

	@NotNull(message = "*family income must be positive value")
	@Digits(integer = 6, fraction = 2)
	private double familyIncome;

	@NotEmpty(message = "*Course must be entered")
	private String dreamCourse;

	private String status;
	private int approvedBy;
	public ScholarshipForm() {
		super();
// TODO Auto-generated constructor stub
	}

	public int getFormId() {
		return formId;
	}

	public void setFormId(int requestId) {
		this.formId = requestId;
	}

	public String getFatherName() {
		return fatherName;
	}

	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}

	public String getMotherName() {
		return motherName;
	}

	public void setMotherName(String motherName) {
		this.motherName = motherName;
	}

	public String getCollege() {
		return college;
	}

	public void setCollege(String college) {
		this.college = college;
	}

	public double getAnnualMarks() {
		return annualMarks;
	}

	public void setAnnualMarks(double annualMarks) {
		this.annualMarks = annualMarks;
	}

	public String getFatherOccupation() {
		return fatherOccupation;
	}

	public void setFatherOccupation(String fatherOccupation) {
		this.fatherOccupation = fatherOccupation;
	}

	public String getMotherOccupation() {
		return motherOccupation;
	}

	public void setMotherOccupation(String motherOccupaation) {
		this.motherOccupation = motherOccupaation;
	}

	public double getFamilyIncome() {
		return familyIncome;
	}

	public void setFamilyIncome(double familyIncome) {
		this.familyIncome = familyIncome;
	}

	public String getDreamCourse() {
		return dreamCourse;
	}

	public void setDreamCourse(String dreamCourse) {
		this.dreamCourse = dreamCourse;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	@Override
	public String toString() {
		return "ScholarshipForm [formId=" + formId + ", userId=" + userId + ", fatherName=" + fatherName
				+ ", motherName=" + motherName + ", college=" + college + ", annualMarks=" + annualMarks
				+ ", fatherOccupation=" + fatherOccupation + ", motherOccupation=" + motherOccupation
				+ ", familyIncome=" + familyIncome + ", dreamCourse=" + dreamCourse + ", status=" + status + "]";
	}

	public int getApprovedBy() {
		return approvedBy;
	}

	public void setApprovedBy(int approvedBy) {
		this.approvedBy = approvedBy;
	}

}
