package com.cognizant.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Transient;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.springframework.stereotype.Component;

@Entity
@Component
public class Student {
     @Id
     @GeneratedValue(strategy = GenerationType.AUTO)
     private int studentId;

     @NotEmpty(message = "First name must be entered")
     @Pattern(regexp = "[A-Za-z]+", message = "First name should be alphabet only")
     @Size(min = 4, message = "firstname atleast min 4 chars")
     private String firstname;

     @NotEmpty(message = "Last name must be entered")
     @Pattern(regexp = "[A-Za-z]+", message = "Last name should be alphabet only")
     @Size(min = 4, message = "lastname atleast min 4 chars")
     private String lastname;

     @NotEmpty(message = "Date must be entered")
     @Pattern(regexp = "^(0[1-9]|[12][0-9]|3[01])[-](0[1-9]|1[012])[-](19|20)[0-9][0-9]$", message = "dob should be dd-mm-yyyy")
     private String dob;

     @NotNull(message = "Select gender")
     private String gender;

     @NotEmpty(message = "Contact number must be entered")
     @Pattern(regexp = "[789][0-9]{9}", message = "Contact number should be digits only")
     private String contactNo;

     @NotEmpty(message = "Email must be entered")
     @Pattern(regexp="^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@" + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$", message="email should be valid")
     private String email;

     @NotEmpty(message = "Address must be entered")
     private String address;

     @NotEmpty(message = "Select category")
     private String category;
     @NotEmpty(message = "Username must be entered")
     @Pattern(regexp = "[A-Za-z0-9_]{6,}", message = "username should be alphanumeric only and of minimum of 6 charactes")
     private String userName;

     @NotEmpty(message = "Password must be entered")
     @Pattern(regexp = "(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}", message = "Password should be valid characters only and of minimum of 8 charactes")
     private String password;

     @NotEmpty(message = "Security question must be entered")
     //@Pattern(regexp = "^[a-zA-Z\\s]+", message = "Security question should be alphabets and ends with ?")
     private String securityQues;

     @NotEmpty(message = "Security answer must be entered")
     //(regexp = "^[a-zA-Z\\s]+", message = "Security answer should be alphabets only")
     private String securityAns;
     
     @Transient
     @NotEmpty(message = "confirmPassword cannot be empty")
     private String confirmPassword;

     public Student() {
           super();
           // TODO Auto-generated constructor stub
     }

     public String getUserName() {
           return userName;
     }

     public String getConfirmPassword() {
           return confirmPassword;
     }

     public void setConfirmPassword(String confirmPassword) {
           this.confirmPassword = confirmPassword;
     }

     public void setUserName(String userName) {
           this.userName = userName;
     }

     public String getPassword() {
           return password;
     }

     public void setPassword(String password) {
           this.password = password;
     }

     public String getSecurityQues() {
           return securityQues;
     }

     public void setSecurityQues(String securityQues) {
           this.securityQues = securityQues;
     }

     public String getSecurityAns() {
           return securityAns;
     }

     public void setSecurityAns(String securityAns) {
           this.securityAns = securityAns;
     }

     public int getStudentId() {
           return studentId;
     }

     public void setStudentId(int studentId) {
           this.studentId = studentId;
     }

     public String getFirstname() {
           return firstname;
     }

     public void setFirstname(String firstname) {
           this.firstname = firstname;
     }

     public String getLastname() {
           return lastname;
     }

     public void setLastname(String lastname) {
           this.lastname = lastname;
     }

     public String getDob() {
           return dob;
     }

     public void setDob(String dob) {
           this.dob = dob;
     }

     public String getGender() {
           return gender;
     }

     public void setGender(String gender) {
           this.gender = gender;
     }

     public String getContactNo() {
           return contactNo;
     }

     public void setContactNo(String contactNo) {
           this.contactNo = contactNo;
     }

     public String getEmail() {
           return email;
     }

     public void setEmail(String email) {
           this.email = email;
     }

     public String getAddress() {
           return address;
     }

     public void setAddress(String address) {
           this.address = address;
     }

     public String getCategory() {
           return category;
     }

     public void setCategory(String category) {
           this.category = category;
     }

     @Override
     public String toString() {
           return "Student [studentId=" + studentId + ", firstname=" + firstname + ", lastname=" + lastname + ", dob="
                     + dob + ", gender=" + gender + ", contactNo=" + contactNo + ", email=" + email + ", address=" + address
                     + ", category=" + category + ", userName=" + userName + ", password=" + password + ", securityQues="
                     + securityQues + ", securityAns=" + securityAns + "]";
     }

}




