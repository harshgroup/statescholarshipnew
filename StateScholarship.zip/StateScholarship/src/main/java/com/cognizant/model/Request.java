package com.cognizant.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Max;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

@Entity
public class Request {

	@Override
	public String toString() {
		return "Request [requestId=" + requestId + ", studentId=" + studentId + ", college=" + college
				+ ", annualMarks=" + annualMarks + ", fatherOccupation=" + fatherOccupation + ", motherOccupaation="
				+ motherOccupaation + ", familyIncome=" + familyIncome + ", dreamCourse=" + dreamCourse + ", status="
				+ status + "]";
	}

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int requestId;
	private int studentId;

	@NotEmpty(message = "College must be entered")
	@Pattern(regexp = "^[a-zA-Z\\s]+", message = "College should be alphabets only")
	private String college;

	@NotNull(message = "annual marks must be positive value")
	@Max(value = 500, message = "marks should be less than 500")
	private double annualMarks;

	@NotEmpty(message = "Father's occupation must be entered")
	@Pattern(regexp = "^[a-zA-Z\\s]+", message = "Father occupation should be alphabets only")
	private String fatherOccupation;

	@NotEmpty(message = "Mother's occupation must be entered")
	@Pattern(regexp = "^[a-zA-Z\\s]+", message = "Mother occupation should be alphabets only")
	private String motherOccupaation;

	@NotNull(message = "family income must be positive value")
	@Digits(integer = 6, fraction = 2)
	private double familyIncome;

	@NotEmpty(message = "Course must be entered")
	private String dreamCourse;

	private String status;

	public Request() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Request(int requestId, int studentId, String college, double annualMarks, String fatherOccupation,
			String motherOccupaation, double familyIncome, String dreamCourse) {
		super();
		this.requestId = requestId;
		this.studentId = studentId;
		this.college = college;
		this.annualMarks = annualMarks;
		this.fatherOccupation = fatherOccupation;
		this.motherOccupaation = motherOccupaation;
		this.familyIncome = familyIncome;
		this.dreamCourse = dreamCourse;
	}

	public int getRequestId() {
		return requestId;
	}

	public void setRequestId(int requestId) {
		this.requestId = requestId;
	}

	public int getStudentId() {
		return studentId;
	}

	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}

	public String getCollege() {
		return college;
	}

	public void setCollege(String college) {
		this.college = college;
	}

	public double getAnnualMarks() {
		return annualMarks;
	}

	public void setAnnualMarks(double annualMarks) {
		this.annualMarks = annualMarks;
	}

	public String getFatherOccupation() {
		return fatherOccupation;
	}

	public void setFatherOccupation(String fatherOccupation) {
		this.fatherOccupation = fatherOccupation;
	}

	public String getMotherOccupaation() {
		return motherOccupaation;
	}

	public void setMotherOccupaation(String motherOccupaation) {
		this.motherOccupaation = motherOccupaation;
	}

	public double getFamilyIncome() {
		return familyIncome;
	}

	public void setFamilyIncome(double familyIncome) {
		this.familyIncome = familyIncome;
	}

	public String getDreamCourse() {
		return dreamCourse;
	}

	public void setDreamCourse(String dreamCourse) {
		this.dreamCourse = dreamCourse;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
