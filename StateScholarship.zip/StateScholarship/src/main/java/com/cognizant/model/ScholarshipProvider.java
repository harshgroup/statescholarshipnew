package com.cognizant.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Transient;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@Entity
public class ScholarshipProvider {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int providerId;
	
	@NotEmpty(message="*First name is required")
	@Pattern(regexp="[A-Za-z]+",message="*first name contains only alphabets")
	@Size(min=2,message="*firstname atleast contain 2 characters")
	private String firstname;
	
	@NotEmpty(message="*Last name is required")
	@Pattern(regexp="[A-Za-z]+",message="*Last name contains only alphabets")
	@Size(min=2,message="lastname atleast min 4 chars")
	private String lastname;
	
	@NotEmpty(message="Contact number must be entered")
	@Pattern(regexp="[789][0-9]{9}",message="Contact number should be digits only")
	private String contactNo;
	
	@NotEmpty(message = "Email must be entered")
	@Pattern(regexp="^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@" + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$", message="email should be valid")
	private String email;
	
	@NotEmpty(message="Address must be entered")
	private String address;
	
	@NotEmpty(message="Username must be entered")
	@Pattern(regexp="[A-Za-z0-9_]{6,}",message="username should be alphanumeric only")
	private String userName;
	
	@NotEmpty(message="Password must be entered")
	@Pattern(regexp="(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}",message="Password should be valid characters only")
	private String password;
	
	@NotEmpty(message="Security question must be entered")
	//@Pattern(regexp="^[a-zA-Z\\s]+",message="Security question should be alphabets and ends with ?")
	private String securityQues;
	
	@NotEmpty(message="Security answer must be entered")
	//@Pattern(regexp="^[a-zA-Z\\s]+",message="Security answer should be alphabets only")
	private String securityAns;
	
	@Transient
    @NotEmpty(message = "confirmPassword cannot be empty")
    private String confirmPassword;


	public ScholarshipProvider() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	public int getProviderId() {
		return providerId;
	}

	public void setProviderId(int providerId) {
		this.providerId = providerId;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getSecurityQues() {
		return securityQues;
	}

	public void setSecurityQues(String securityQues) {
		this.securityQues = securityQues;
	}

	public String getSecurityAns() {
		return securityAns;
	}

	public void setSecurityAns(String securityAns) {
		this.securityAns = securityAns;
	}

	@Override
	public String toString() {
		return "ScholorshipProvider [providerId=" + providerId + ", firstname=" + firstname + ", lastname=" + lastname
				+ ", contactNo=" + contactNo + ", email=" + email + ", address=" + address + ", userName=" + userName
				+ ", password=" + password + ", securityQues=" + securityQues + ", securityAns=" + securityAns + "]";
	}


	public String getConfirmPassword() {
		return confirmPassword;
	}


	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}
	
	
	

}
