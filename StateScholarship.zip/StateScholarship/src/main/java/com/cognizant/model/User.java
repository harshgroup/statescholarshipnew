package com.cognizant.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Transient;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.springframework.stereotype.Component;

@Entity
@Component
public class User {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int userId;

	@NotEmpty(message = "*Username is required")
	@Pattern(regexp = "[A-Za-z0-9_]{6,}", message = "*username should be 6 digits and only alphabets and numbers")
	private String userName;

	@NotEmpty(message = "*First name is required")
	@Pattern(regexp = "[A-Za-z]+", message = "*First name should be alphabet only")
	@Size(min = 2, message = "*minimum 2 characters required")
	private String firstName;

	@NotEmpty(message = "*Last name is required")
	@Pattern(regexp = "[A-Za-z]+", message = "*Last name should be alphabet only")
	@Size(min = 2, message = "*minimum 2 characters required")
	private String lastName;

	@NotEmpty(message = "*Date is required")
	// @Pattern(regexp =
	// "^(0[1-9]|[12][0-9]|3[01])[-](0[1-9]|1[012])[-](19|20)[0-9][0-9]$", message =
	// "dob should be dd-mm-yyyy")
	private String dob;

	@NotEmpty(message = "*Select gender")
	private String gender;

	@NotEmpty(message = "*Contact number is required")
	@Pattern(regexp = "[789][0-9]{9}", message = "Contact number should be digits only")
	private String contactNo;

	@NotEmpty(message = "*Email is required")
	@Pattern(regexp = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
			+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$", message = "email should be valid")
	private String email;

	@NotEmpty(message = "*Address is required")
	private String address;

	@NotEmpty(message = "*category is required")
	private String category;

	@NotEmpty(message = "*Password is required")
	@Pattern(regexp = "(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}", message = "Password should be valid characters only and of minimum of 8 charactes")
	private String password;

	@Transient
	@NotEmpty(message = "*confirmPassword is required")
	private String confirmPassword;

	@NotEmpty(message = "*Security question is required")
	// @Pattern(regexp = "^[a-zA-Z\\s]+", message = "Security question should be
	// alphabets and ends with ?")
	private String securityQues;

	@NotEmpty(message = "*Security answer is required")
	// (regexp = "^[a-zA-Z\\s]+", message = "Security answer should be alphabets
	// only")
	private String securityAns;

	@NotEmpty(message = "*Select role")
	private String role;

	public User() {
		super();
// TODO Auto-generated constructor stub
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getSecurityQues() {
		return securityQues;
	}

	public void setSecurityQues(String securityQues) {
		this.securityQues = securityQues;
	}

	public String getSecurityAns() {
		return securityAns;
	}

	public void setSecurityAns(String securityAns) {
		this.securityAns = securityAns;
	}

	public String getConfirmPassword() {
		return confirmPassword;
	}

	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	@Override
	public String toString() {
		return "User [userId=" + userId + ", userName=" + userName + ", firstName=" + firstName + ", lastName="
				+ lastName + ", dob=" + dob + ", gender=" + gender + ", contactNo=" + contactNo + ", email=" + email
				+ ", address=" + address + ", password=" + password + ", securityQues=" + securityQues
				+ ", securityAns=" + securityAns + ", confirmPassword=" + confirmPassword + ", role=" + role + "]";
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

}