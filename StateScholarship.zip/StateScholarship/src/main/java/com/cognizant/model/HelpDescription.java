package com.cognizant.model;

public class HelpDescription {

}
