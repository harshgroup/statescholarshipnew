package com.cognizant.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotEmpty;

import org.springframework.stereotype.Component;

@Entity
@Component
public class HelpDescription {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int descriptionId;

	@NotEmpty(message = "subject cannot be empty")
	private String issue;

	@NotEmpty(message = "description cannot be empty")
	private String description;

	private String solution;

	private String status;

	private int userId;

	public HelpDescription() {
		super();
	}

	public int getDescriptionId() {
		return descriptionId;
	}

	public void setDescriptionId(int descriptionId) {
		this.descriptionId = descriptionId;
	}

	public String getIssue() {
		return issue;
	}

	public void setIssue(String issue) {
		this.issue = issue;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getSolution() {
		return solution;
	}

	public void setSolution(String solution) {
		this.solution = solution;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int helpId) {
		this.userId = helpId;
	}

	@Override
	public String toString() {
		return "HelpDescription [descriptionId=" + descriptionId + ", issue=" + issue + ", description=" + description
				+ ", solution=" + solution + ", status=" + status + ", userId=" + userId + "]";
	}

}
