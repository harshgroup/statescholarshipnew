package com.cognizant.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.springframework.stereotype.Component;

@Entity
@Component
public class Admin {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int adminId;

	@NotEmpty(message = "Name must be entered")
	@Pattern(regexp = "[A-Za-z]+", message = "Name should be alphabet only")
	@Size(min = 4, message = "Name atleast min 4 chars")
	private String name;

	@NotEmpty(message = "Username must be entered")
	@Pattern(regexp = "[A-Za-z0-9_]{6,}", message = "username should be alphanumeric only and of minimum of 6 charactes")
	private String userName;

	@NotEmpty(message = "Password must be entered")
	@Pattern(regexp = "(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}", message = "Password should be valid characters only and of minimum of 8 charactes")
	private String password;

	@NotEmpty(message = "Security question must be entered")
	private String securityQues;

	@NotEmpty(message = "Security answer must be entered")
	private String securityAns;

	public Admin() {
		super();
	}

	public int getAdminId() {
		return adminId;
	}

	public void setAdminId(int adminId) {
		this.adminId = adminId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getSecurityQues() {
		return securityQues;
	}

	public void setSecurityQues(String securityQues) {
		this.securityQues = securityQues;
	}

	public String getSecurityAns() {
		return securityAns;
	}

	public void setSecurityAns(String securityAns) {
		this.securityAns = securityAns;
	}

	@Override
	public String toString() {
		return "Admin [adminId=" + adminId + ", name=" + name + ", userName=" + userName + ", password=" + password
				+ ", securityQues=" + securityQues + ", securityAns=" + securityAns + "]";
	}

}
