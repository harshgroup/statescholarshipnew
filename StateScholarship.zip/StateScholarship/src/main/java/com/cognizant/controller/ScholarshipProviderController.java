package com.cognizant.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cognizant.model.Request;
import com.cognizant.model.ScholarshipProvider;
import com.cognizant.model.Student;
import com.cognizant.repository.RequestRepository;
import com.cognizant.repository.ScholarshipProviderRepository;
import com.cognizant.repository.StudentRepository;

@Controller
public class ScholarshipProviderController {
	@Autowired
	private ScholarshipProviderRepository scholarshipProviderRepository;
	private HttpSession session;
	@Autowired
	private RequestRepository requestRepository;
	@Autowired
	private StudentRepository studentRepository;

	@RequestMapping("/scholarshipproviderlogin")
	public String showScholarshipProviderLoginForm(
			@ModelAttribute("scholarshipProvider") ScholarshipProvider scholarshipProvider) {

		scholarshipProvider = new ScholarshipProvider();
		return "scholarshipproviderlogin";
	}

	@RequestMapping("/scholarshipproviderhomepage")
	public String showStudentHomePage(@ModelAttribute("scholarshipProvider") ScholarshipProvider scholarshipProvider,
			HttpServletRequest request, Model model) {
		ScholarshipProvider scholarshipProvider1 = scholarshipProviderRepository.getScholarshipProviderLoginPassword(
				scholarshipProvider.getUserName(), scholarshipProvider.getPassword());
		System.out.println(scholarshipProvider);
		System.out.println(scholarshipProvider1);
		if (scholarshipProvider1 != null) {
			session = request.getSession();
			session.setAttribute("scholarshipProvider1", scholarshipProvider1);
			System.out.println(((ScholarshipProvider) session.getAttribute("scholarshipProvider1")).getFirstname());
			return "scholarshipproviderhomepage";

		} else {
			model.addAttribute("wrongPasswordOrUserName", "Wrong Username or password");
			return "scholarshipproviderlogin";
		}

	}

	@RequestMapping("/showregistrationpage")
	public String viewScholarshipProviderRegistrationPage(
			@ModelAttribute("scholarshipProvider") ScholarshipProvider scholarshipProvider, Model model) {
		if (scholarshipProviderRepository.count() < 1) {
			scholarshipProvider = new ScholarshipProvider();
			return "scholarshipproviderregistration";
		} else {
			model.addAttribute("userExist", "Scholarship provider already exist");
			return "scholarshipproviderlogin";
		}
	}

	@ModelAttribute("securityQuestionList")
	public List<String> securityQuestion() {
		List<String> securityQuestionList = new ArrayList<String>();
		securityQuestionList.add("Mother's maiden name.");
		securityQuestionList.add("Name of town where you were born.");
		securityQuestionList.add("Name of first pet.");
		return securityQuestionList;
	}

	@RequestMapping("/scholarshipproviderregister")
	public String saveScholarshipProvider(
			@Valid @ModelAttribute("scholarshipProvider") ScholarshipProvider scholarshipProvider,
			BindingResult bindingResult, Model model) {
		System.out.println(scholarshipProvider);

		if (bindingResult.hasErrors()) {

			return "scholarshipproviderregistration";
		}
		if (scholarshipProvider.getConfirmPassword().equals(scholarshipProvider.getPassword())) {
			scholarshipProviderRepository.save(scholarshipProvider);
			model.addAttribute("status", "successfully registered");
			return "scholarshipproviderlogin";
		}

		else {
			model.addAttribute("checkPassword", "password and confirm password should be same");
			return "scholarshipproviderregistration";
		}

	}

	@RequestMapping("/splogout")
	public String scholarshipProviderLogout(
			@ModelAttribute("scholarshipProvider") ScholarshipProvider scholarshipProvider) {
		try {
			session.invalidate();
		} catch (java.lang.IllegalStateException e) {
			return "logout";
		}
		return "logout";
	}

	@RequestMapping("/incomingrequest")
	public String viewIncomingRequest(Model m) {
		List<Request> requestList = requestRepository.findAllRequestsByStatus("Not verified");

		if (requestList != null) {
			m.addAttribute("requestlist", requestList);

			return "incomingrequest";
		} else {
			System.out.println("request not present");
			return "scholarshipproviderhomepage";
		}
	}

	@RequestMapping("sphome")
	public String showHomePage() {

		return "scholarshipproviderhomepage";
	}

	@RequestMapping("studentrequestform")
	public String showStudentRequestForm(@RequestParam int requestId, Model m) {
		Optional<Request> opr = requestRepository.findById(requestId);
		if (opr.isPresent()) {
			Request request = opr.get();
			m.addAttribute("request", request);
			
			Optional<Student> ops = studentRepository.findById(request.getStudentId());

			if (ops.isPresent()) {
				Student student = ops.get();
				m.addAttribute("student", student);
			} else {
				System.out.println("student Not present");
			}
		} else {
			System.out.println("request Not present");
		}
		
		return "studentrequestform";
	}
	
	@RequestMapping("studentrequestform1")
	public String showStudentRequestFormAfterStatus(@RequestParam int requestId, Model m) {
		Optional<Request> opr = requestRepository.findById(requestId);
		if (opr.isPresent()) {
			Request request = opr.get();
			m.addAttribute("request", request);
			
			Optional<Student> ops = studentRepository.findById(request.getStudentId());

			if (ops.isPresent()) {
				Student student = ops.get();
				m.addAttribute("student", student);
			} else {
				System.out.println("student Not present");
			}
		} else {
			System.out.println("request Not present");
		}
		
		return "studentviewrequest";
	}
	
	@RequestMapping("/updatestatus")
	public String updateStatus(@RequestParam String status,@RequestParam String requestId, Model m) {
		System.out.println(status);
		System.out.println(requestId);
		requestRepository.updateStatusByRequestId(status, Integer.parseInt(requestId));
		m.addAttribute("status","request has " + status);
		return "scholarshipproviderhomepage";
		
	}
	
	
	
	@RequestMapping("/approvedrequest")
	public String viewApprovedRequest(Model m) {
		List<Request> requestList = requestRepository.findAllRequestsByStatus("accepted");

		if (requestList != null) {
			m.addAttribute("requestlist", requestList);

			return "approvedrequest";
		} else {
			System.out.println("request not present");
			return "scholarshipproviderhomepage";
		}
	}
	@RequestMapping("/rejectedrequest")
	public String viewRejectedRequest(Model m) {
		List<Request> requestList = requestRepository.findAllRequestsByStatus("rejected");

		if (requestList != null) {
			m.addAttribute("requestlist", requestList);

			return "rejectedrequest";
		} else {
			System.out.println("request not present");
			return "scholarshipproviderhomepage";
		}
	}

}