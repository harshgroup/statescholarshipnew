package com.cognizant.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cognizant.model.ScholarshipForm;
import com.cognizant.model.User;
import com.cognizant.service.ScholarshipFormService;
import com.cognizant.service.UserService;

@Controller
public class ScholarshipProviderController {
	@Autowired
	private ScholarshipFormService scholarshipFormService;
	private HttpSession session;
	@Autowired
	private UserService userService;

	@RequestMapping("/viewrequest")
	public String viewIncomingRequest(HttpServletRequest request, Model m) {
		session = request.getSession();
		List<ScholarshipForm> formList = scholarshipFormService.fetchAllRequests("Not verified");
		if (formList != null) {

			m.addAttribute("formList", formList);
			return "incomingrequest";
		} else {
			System.out.println("request not present");
			return "scholarshipproviderhomepage";
		}
	}

	@RequestMapping("sphome")
	public String showHomePage() {

		return "scholarshipproviderhomepage";
	}

	@RequestMapping("studentscholarshipform")
	public String showStudentRequestForm(@RequestParam int formId, Model m) {
		ScholarshipForm form = scholarshipFormService.fetchFormByFormId(formId);
		if (form != null) {
			m.addAttribute("form", form);
			User student = userService.fetchUser(form.getUserId());
			if (student != null) {
				m.addAttribute("student", student);
			} else {
				System.out.println("student Not present");
			}
		} else {
			System.out.println("request Not present");
		}

		return "approveform";
	}

	@RequestMapping("approvedform")
	public String showStudentRequestFormAfterStatus(@RequestParam int formId, Model m) {
		ScholarshipForm form = scholarshipFormService.fetchFormByFormId(formId);
		if (form != null) {
			m.addAttribute("form", form);
			User student = userService.fetchUser(form.getUserId());
			if (student != null) {
				m.addAttribute("student", student);
				m.addAttribute("approvedBy", userService.fetchFirstName(form.getApprovedBy()) + " "
						+ userService.fetchLastName(form.getApprovedBy()));
			} else {
				System.out.println("student Not present");
			}
		} else {
			System.out.println("request Not present");
		}

		return "studentviewrequest";
	}

	@RequestMapping(value = "/updatestatus", method = RequestMethod.POST)
	public String updateStatus(@RequestParam String status, @RequestParam String formId, Model m) {
		System.out.println(status);
		System.out.println(formId);
		User scholarshipProvider = (User) session.getAttribute("scholarshipprovider");
		scholarshipFormService.updateStatus(status, Integer.parseInt(formId));
		scholarshipFormService.updateApprovedBy(scholarshipProvider.getUserId(), Integer.parseInt(formId));
		m.addAttribute("status", "request has " + status);
		return "scholarshipproviderhomepage";

	}

	@RequestMapping("/approvedrequest")
	public String viewApprovedRequest(Model m) {
		List<ScholarshipForm> formList = scholarshipFormService.fetchAllRequests("accepted");

		if (formList != null) {
			m.addAttribute("formList", formList);

			return "approvedrequest";
		} else {
			System.out.println("request not present");
			return "scholarshipproviderhomepage";
		}
	}

}