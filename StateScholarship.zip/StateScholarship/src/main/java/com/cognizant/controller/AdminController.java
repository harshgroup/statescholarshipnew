package com.cognizant.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cognizant.model.Admin;
import com.cognizant.model.ScholarshipProvider;
import com.cognizant.model.Student;
import com.cognizant.repository.AdminRepository;

@Controller
public class AdminController {
	@Autowired
	AdminRepository adminRepository;
	HttpSession session;

	@RequestMapping("/adminlogin")
	public String showAdminLoginForm(@ModelAttribute("admin") Admin admin) {
		admin = new Admin();
		return "adminlogin";
	}

	@RequestMapping("/adminhomepage")
	public String showAdminHomePage(@ModelAttribute("admin") Admin admin, HttpServletRequest request, Model model) {
		Admin admin1 = adminRepository.getAdminLoginPassword(admin.getUserName(), admin.getPassword());
		if (admin1 != null) {
			session = request.getSession();
			session.setAttribute("admin1", admin);
			//System.out.println(((Admin) session.getAttribute("admin1")).getName());
			return "adminhomepage";

		} else {
			model.addAttribute("wrongPasswordOrUserName", "Wrong Username or password");
			return "adminlogin";
		}

	}
	@RequestMapping("/adminlogout")
	public String adminLogout(@ModelAttribute("admin") Admin admin) {
		try {
			session.invalidate();
		} catch (java.lang.IllegalStateException e) {
			return "logout";
		}
		return "logout";
	} 

}
