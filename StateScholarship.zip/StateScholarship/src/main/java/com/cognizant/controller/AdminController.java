package com.cognizant.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cognizant.dto.HelpUserDto;
import com.cognizant.model.HelpDescription;
import com.cognizant.model.User;
import com.cognizant.service.HelpDescriptionService;
import com.cognizant.service.UserService;

import java.util.List;

@Controller
public class AdminController {
	@Autowired
	HelpDescriptionService helpDescriptionService;
	@Autowired
	UserService userService;
	@RequestMapping("adminhomepage")
	public String showHomePage() {

		return "adminhomepage";
	}

	@RequestMapping("viewissue")
	public String viewIssueByUserId(Model model) {
		List<HelpUserDto> userIds = helpDescriptionService.fetchUserIds("Pending");
		model.addAttribute("userIds", userIds);
		return "viewissuesbyuserid";
	}

	@RequestMapping("viewissuesofstudent")
	public String viewIssuesofStudent(@RequestParam String userId, Model model) {
		List<HelpDescription> helpDescriptions = helpDescriptionService.fetchDescriptions(Integer.parseInt(userId),
				"Pending");
		model.addAttribute("descriptionList", helpDescriptions);
		model.addAttribute("student", userService.fetchUser(Integer.parseInt(userId)));
		return "viewissuesofstudent";
	}

	@RequestMapping("providesolution")
	public String provideSolution(@ModelAttribute("helpDescription") HelpDescription helpDescription,
			@RequestParam String descriptionId, Model model) {
		helpDescription = helpDescriptionService.fetchDescription(descriptionId);
		if (helpDescription != null) {
			model.addAttribute("helpDescription", helpDescription);
			return "givestudentissuesolution";
		} else {
			System.out.println("there are issues");
			return "adminhomepage";
		}
	}

	@RequestMapping("/sendsolution")
	public String sendSolution( @ModelAttribute("helpDescription") HelpDescription helpDescription, BindingResult bindingResult,Model model) {
		System.out.println(helpDescription);
		if(bindingResult.hasErrors()) {
			model.addAttribute("helpDescription", helpDescription);
			return "givestudentissuesolution";
		}
		System.out.println(helpDescription);
		String solution = helpDescription.getSolution();
		int descriptionId = helpDescription.getDescriptionId();
		System.out.println(solution + " " + descriptionId);
		helpDescriptionService.updateStatus(descriptionId, "Resolved");
		helpDescriptionService.updateSolution(descriptionId, solution);
		model.addAttribute("success", "solution provided");
		return "adminhomepage";
	}

	@RequestMapping("viewresolvedissue")
	public String viewResolvedIssueByStatus(Model model) {
		List<HelpDescription> helpDescriptions = helpDescriptionService.fetchDescriptions("Resolved");
		model.addAttribute("descriptionList", helpDescriptions);
		return "viewresolvedissuesbystatus";
	}

	@RequestMapping("viewresolvedsolution")
	public String viewResolvedSolution(@RequestParam String descriptionId, Model model) {
		HelpDescription helpDescription = helpDescriptionService.fetchDescription(descriptionId);
		if (helpDescription != null) {
			int userId = helpDescription.getUserId();
			User student = userService.fetchUser(userId);
			String name = student.getFirstName() + " " + student.getLastName();
			model.addAttribute("name",name);
			model.addAttribute("userId",userId);
			model.addAttribute("helpDescription", helpDescription);
			return "viewissuedetail";
		} else {
			System.out.println("there are issues");
			return "helpstudent";
		}
	}

}
