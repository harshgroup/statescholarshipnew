package com.cognizant.controller;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cognizant.model.Admin;
import com.cognizant.model.ScholarshipProvider;
import com.cognizant.model.Student;

@Controller
public class BaseController {
	HttpSession session;
	@RequestMapping("/index")
	public String showIndexPage() {
		return "index";
	}
	@RequestMapping("/displaylogin")
	public String displayLoginPage(@RequestParam String category, Student student, Admin admin, ScholarshipProvider scholarshipProvider) {
		
		if(category.equals("admin")) {
			admin = new Admin();
			return "adminlogin";
		} else if(category.equals("scholarshipProvider")) {
			scholarshipProvider = new ScholarshipProvider();
			return "scholarshipproviderlogin";
		} else {
			student = new Student();
			return "studentlogin";
		}
	}
}
