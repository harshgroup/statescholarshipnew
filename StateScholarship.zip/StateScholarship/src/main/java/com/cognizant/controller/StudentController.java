package com.cognizant.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cognizant.model.HelpDescription;
import com.cognizant.model.ScholarshipForm;

import com.cognizant.model.User;
import com.cognizant.service.HelpDescriptionService;
import com.cognizant.service.ScholarshipFormService;
import com.cognizant.service.UserService;

@Controller
public class StudentController {
	@Autowired
	UserService userService;
	HttpSession session;
	@Autowired
	ScholarshipFormService scholarshipFormService;
	@Autowired
	HelpDescriptionService helpDescriptionService;

	@RequestMapping("/scholarshipform")

	public String showScholarshipForm(@ModelAttribute("scholarshipForm") ScholarshipForm scholarshipForm,
			HttpServletRequest request, Model model) {
		session = request.getSession();
		User student = ((User) session.getAttribute("student"));
		ScholarshipForm form = scholarshipFormService.fetchForm(student.getUserId());
		if (form == null) {
			scholarshipForm = new ScholarshipForm();
			return "scholarshipform";
		} else {
			model.addAttribute("alredySubmitted",
					"You have successfully filled the form. Click on view status to see your current status of scholarship request.");
			return "studenthomepage";
		}
	}

	@RequestMapping("/submitform")
	public String submitScholarshipForm(@Valid @ModelAttribute("scholarshipForm") ScholarshipForm scholarshipForm,
			BindingResult bindingResult, HttpServletRequest request, Model model) {
		if (bindingResult.hasErrors()) {
			System.out.println(scholarshipForm);
			System.out.println("some error");
			System.out.println(bindingResult.getErrorCount());
			return "scholarshipform";
		}
		session = request.getSession();
		scholarshipForm.setUserId(((User) session.getAttribute("student")).getUserId());
		scholarshipForm.setStatus("Not verified");
		scholarshipFormService.saveForm(scholarshipForm);
		model.addAttribute("alredySubmitted",
				"You have successfully filled the form. Click on view status to see your current status of scholarship request.");
		return "studenthomepage";
	}

	@RequestMapping("/formstatus")
	public String viewFormStatus(HttpServletRequest request, Model model) {
		session = request.getSession();
		if (session != null) {
			User user = (User) session.getAttribute("student");
			System.out.println(user);
			ScholarshipForm form = scholarshipFormService.fetchForm(user.getUserId());
			if (form != null) {
				if (form.getStatus().equals("Not verified")) {
					model.addAttribute("seeStatus",
							"Not verified Yet! Your request has been sent to scholarship provider.");
				} else if (form.getStatus().equals("accepted")) {
					model.addAttribute("seeStatus",
							"Congratulations! Your request has been accepted by "
									+ userService.fetchFirstName(form.getApprovedBy()) + " "
									+ userService.fetchLastName(form.getApprovedBy()) + ". We will contact you soon!");
				} else {
					model.addAttribute("seeStatus", "Sorry! Your request has been rejected!");
				}
			} else {
				model.addAttribute("seeStatus", "You haven't filled the form!!");
				System.out.println("request not present");
			}
			return "studenthomepage";
		} else {
			System.out.println("session is null");
			return "studenthomepage";
		}
	}

	@RequestMapping("/viewform")
	public String viewForm(HttpServletRequest request, Model model) {
		session = request.getSession();
		User user = (User) session.getAttribute("student");
		System.out.println(user);
		ScholarshipForm form = scholarshipFormService.fetchForm(user.getUserId());
		if (form != null)
			model.addAttribute("form", form);
		else {
			model.addAttribute("seeStatus", "You haven't filled the form!!");
			System.out.println("form not present");
		}
		return "studenthomepage";
	}

	@RequestMapping("studenthome")
	public String showHomePage() {

		return "studenthomepage";
	}

	@RequestMapping("/helpstudent")
	public String studentHelp() {
		return "studenthelp";
	}

	@RequestMapping("reportissue")
	public String reportIssue(@ModelAttribute("helpdescription") HelpDescription helpDescription) {
		helpDescription = new HelpDescription();
		return "reportIssue";
	}
	
	@ModelAttribute("issueList")
	public List<String> issue() {
		List<String> issueList = new ArrayList<String>();
		issueList.add("scholarship form");
		issueList.add("scholarship money");
		issueList.add("Scholarship Provider");
		issueList.add("Website issue");
		return issueList;
	}
	@RequestMapping("previousissues")
	public String viewPreviousIssues(HttpServletRequest request,Model model) {
		session = request.getSession();
		User student = (User) session.getAttribute("student");
		int userId = student.getUserId();
		List<HelpDescription> helpDescriptions = helpDescriptionService.fetchDescriptions(userId);
		model.addAttribute("descriptionList", helpDescriptions);
		return "viewpreviousissues";
	}
	@RequestMapping("/sendissue")
	public String sendIssue(@ModelAttribute("helpdescription") HelpDescription helpDescription,
			HttpServletRequest request, Model model) {
		session = request.getSession();
		User student = (User) session.getAttribute("student");
		int userId = student.getUserId();
		helpDescription.setUserId(userId);
		helpDescription.setStatus("Pending");
		System.out.println(helpDescription);
		helpDescriptionService.saveDescription(helpDescription);
		List<HelpDescription> helpDescriptions = helpDescriptionService.fetchDescriptions(userId);
		model.addAttribute("descriptionList", helpDescriptions);
		return "viewpreviousissues";
	}
	
	@RequestMapping("issuesolution")
	public String issueSolution(@RequestParam String descriptionId, Model model) {
		HelpDescription helpDescription = helpDescriptionService.fetchDescription(descriptionId);
		if(helpDescription!=null) {
			int userId = helpDescription.getUserId();
			User student = userService.fetchUser(userId);
			String name = student.getFirstName() + " " + student.getLastName();
			model.addAttribute("name",name);
			model.addAttribute("userId",userId);
			model.addAttribute("helpDescription",helpDescription);
			return "viewissuedetailbystudent";
		} else {
			System.out.println("there are issues");
			return "helpstudent";
		}
		
	}
	
}
