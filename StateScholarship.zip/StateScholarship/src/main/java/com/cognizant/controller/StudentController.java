package com.cognizant.controller;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cognizant.model.ScholarshipForm;

import com.cognizant.model.User;
import com.cognizant.service.ScholarshipFormService;
import com.cognizant.service.UserService;

@Controller
public class StudentController {
	@Autowired
	UserService userService;
	HttpSession session;
	@Autowired
	ScholarshipFormService scholarshipFormService;

	@RequestMapping("/scholarshipform")
	public String showRequestPage(@ModelAttribute("scholarshipForm") ScholarshipForm scholarshipForm, Model model) {
		User student = ((User) session.getAttribute("student"));
		ScholarshipForm form = scholarshipFormService.fetchForm(student.getUserId());
		if (form == null) {
			scholarshipForm = new ScholarshipForm();
			return "scholarshipform";
		} else {
			model.addAttribute("alredySubmitted",
					"You have successfully filled the form. Click on view status to see your current status of scholarship request.");
			return "studenthomepage";
		}
	}

	@RequestMapping("/submitform")
	public String submitScholarshipForm(@Valid @ModelAttribute("scholarshipForm") ScholarshipForm scholarshipForm,
			BindingResult bindingResult, Model model) {
		if (bindingResult.hasErrors()) {
			return "scholarshipform";
		}
		scholarshipForm.setUserId(((User) session.getAttribute("student")).getUserId());
		scholarshipForm.setStatus("Not verified");
		scholarshipFormService.saveForm(scholarshipForm);
		model.addAttribute("alredySubmitted",
				"You have successfully filled the form. Click on view status to see your current status of scholarship request.");
		return "studenthomepage";
	}

	@RequestMapping("/formstatus")
	public String viewFormStatus(Model model) {
		User user = (User) session.getAttribute("student");
		System.out.println(user);
		ScholarshipForm form = scholarshipFormService.fetchForm(user.getUserId());
		if (form != null) {
			if (form.getStatus().equals("not verified")) {
				model.addAttribute("seeStatus",
						"Not verified Yet! Your request has been sent to scholarship provider.");
			} else if (form.getStatus().equals("accepted")) {
				model.addAttribute("seeStatus",
						"Congratulations! Your request has been accepted by "
								+ userService.fetchFirstName(form.getApprovedBy()) + " "
								+ userService.fetchLastName(form.getApprovedBy()) + ". We will contact you soon!");
			} else {
				model.addAttribute("seeStatus", "Sorry! Your request has been rejected!");
			}
		} else {
			model.addAttribute("seeStatus", "You haven't filled the form!!");
			System.out.println("request not present");
		}
		return "studenthomepage";
	}

	@RequestMapping("/viewform")
	public String viewForm(Model model) {
		User user = (User) session.getAttribute("student");
		System.out.println(user);
		ScholarshipForm form = scholarshipFormService.fetchForm(user.getUserId());
		if (form != null)
			model.addAttribute("form", form);
		else {
			model.addAttribute("seeStatus", "You haven't filled the form!!");
			System.out.println("form not present");
		}
		return "studenthomepage";
	}

	@RequestMapping("studenthome")
	public String showHomePage() {

		return "studenthomepage";
	}
}
