package com.cognizant.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cognizant.model.Request;
import com.cognizant.model.Student;
import com.cognizant.repository.RequestRepository;
import com.cognizant.repository.StudentRepository;

@Controller
public class StudentController {
	@Autowired
	StudentRepository studentRepository;
	HttpSession session;
	@Autowired
	RequestRepository requestRepository;

	@RequestMapping("/studentlogin")
	public String showStudentLoginForm(@ModelAttribute("student") Student student) {

		student = new Student();
		System.out.print(student);
		return "studentlogin";
	}

	@RequestMapping("/studenthomepage")
	public String showStudentHomePage(@ModelAttribute("student") Student student, HttpServletRequest request,
			Model model) {
		Student student1 = studentRepository.getStudentLoginPassword(student.getUserName(), student.getPassword());
		System.out.println(student1);
		if (student1 != null) {
			session = request.getSession();
			session.setAttribute("student1", student1);
			System.out.println(((Student) session.getAttribute("student1")).getFirstname());
			return "studenthomepage";

		} else {
			model.addAttribute("wrongPasswordOrUserName", "Wrong Username or password");
			return "studentlogin";
		}

	}

	@RequestMapping("/showregpage")
	public String viewStudentRegistrationPage(@ModelAttribute("student") Student student) {

		student = new Student();
		return "studentregistration";
	}

	@ModelAttribute("securityQuestionList")
	public List<String> securityQuestion() {
		List<String> securityQuestionList = new ArrayList<String>();
		securityQuestionList.add("Mother's maiden name.");
		securityQuestionList.add("Name of town where you were born.");
		securityQuestionList.add("Name of first pet.");
		return securityQuestionList;
	}

	@ModelAttribute("categoryList")
	public List<String> category() {
		List<String> categoryList = new ArrayList<String>();
		categoryList.add("General");
		categoryList.add("OBC");
		categoryList.add("SC/ST");
		categoryList.add("others");
		return categoryList;
	}

	@RequestMapping("/studentregister")
	public String saveStudent(@Valid @ModelAttribute("student") Student student, BindingResult bindingResult,
			Model model) {
		System.out.println(student);

		if (bindingResult.hasErrors()) {

			return "studentregistration";
		}
		if (student.getConfirmPassword().equals(student.getPassword())) {
			studentRepository.save(student);
			model.addAttribute("status", "successfully registered");
			return "studentlogin";
		}

		else {
			model.addAttribute("checkPassword", "password and confirm password should be same");
			return "studentregistration";
		}

	}

	@RequestMapping("/request")
	public String showRequestPage(@ModelAttribute("request") Request request, Model model) {
		Student student = ((Student) session.getAttribute("student1"));
		Request request1 = requestRepository.findRequestByStudentId(student.getStudentId());
		if (request1 == null) {
			request = new Request();
			return "request";
		} else {
			model.addAttribute("alredySubmitted", "You have already submitted form");
			return "studenthomepage";
		}
	}

	@RequestMapping("/requestsubmitedsuccessfully")
	public String submitRequest(@Valid @ModelAttribute("request") Request request, BindingResult bindingResult,
			Model model) {
		if (bindingResult.hasErrors()) {
			return "request";
		}
		request.setStudentId(((Student) session.getAttribute("student1")).getStudentId());
		request.setStatus("Not verified");
		requestRepository.save(request);
		model.addAttribute("successstatus", "Successfully Submitted!");
		return "studenthomepage";
	}

	@RequestMapping("/studentlogout")
	public String studentLogout(@ModelAttribute("student") Student student) {
		try {
			session.invalidate();
		} catch (java.lang.IllegalStateException e) {
			return "logout";
		}
		return "logout";
	}

	@RequestMapping("/requeststatus")
	public String viewRequestStatus(Model model) {
		Student student = (Student) session.getAttribute("student1");
		System.out.println(student);
		Request request = requestRepository.findRequestByStudentId(student.getStudentId());
		if (request != null)
			model.addAttribute("seeStatus", request.getStatus());
		else {
			model.addAttribute("seeStatus", "You haven't submitted the form!!");
			System.out.println("request not present");
		}
		return "studenthomepage";
	}
	
	@RequestMapping("studenthome")
	public String showHomePage() {
		
		return "studenthomepage";
	}
}
