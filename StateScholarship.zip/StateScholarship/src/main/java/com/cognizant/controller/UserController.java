package com.cognizant.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cognizant.dto.FormUserDto;
import com.cognizant.dto.HelpUserDto;
import com.cognizant.model.ScholarshipForm;
import com.cognizant.model.User;
import com.cognizant.service.HelpDescriptionService;
import com.cognizant.service.ScholarshipFormService;
import com.cognizant.service.UserService;

@Controller
public class UserController {
	@Autowired
	UserService userService;
	HttpSession session;
	@Autowired
	ScholarshipFormService scholarshipFormService;
	@Autowired
	HelpDescriptionService helpDescriptionService;
	
	@RequestMapping("/")
	public String showLoginWithoutURL(@ModelAttribute("user") User user) {

		user = new User();
		System.out.print(user);
		return "login";
	}

	@RequestMapping("/login")
	public String showLogin(@ModelAttribute("user") User user) {

		user = new User();
		System.out.print(user);
		return "login";
	}

	@RequestMapping("/homepage")
	public String showHomePage(@ModelAttribute("user") User user, HttpServletRequest request, Model model) {
		String username = user.getUserName();
		String password = user.getPassword();
		if (userService.fetchUserName(username) != null) {
			if (userService.fetchPassowrd(username).equals(password)) {
				session = request.getSession();
				String role = userService.fetchRole(username);

				if (role.equals("student")) {
					User student = userService.fetchUser(username);
					ScholarshipForm form = scholarshipFormService.fetchForm(student.getUserId());
					if (form != null) {
						if (form.getStatus().equals("Not verified")) {
							model.addAttribute("seeStatusNotverified",
									"Your Request has not verified Yet! Your request has been sent to scholarship provider.");
						} else if (form.getStatus().equals("accepted")) {
							model.addAttribute("seeStatusCongrats",
									"Congratulations! Your request has been accepted by "
											+ userService.fetchFirstName(form.getApprovedBy()) + " "
											+ userService.fetchLastName(form.getApprovedBy()) + ". We will contact you soon!");
						} else {
							model.addAttribute("seeStatusReject", "Sorry! Your request has been rejected!");
						}
					} 
					session.setAttribute("student", student);
					return "studenthomepage";
				} else if (role.equals("scholarshipprovider")) {
					User scholarshipprovider = userService.fetchUser(username);
					List<FormUserDto> formList = scholarshipFormService.fetchAllRequests("accepted");
					System.out.println(formList);
					if (formList != null) {
						System.out.println("formList is not null");
						model.addAttribute("formList", formList);
						session.setAttribute("scholarshipprovider", scholarshipprovider);
						return "scholarshipproviderhomepage";
					}
					session.setAttribute("scholarshipprovider", scholarshipprovider);
					return "scholarshipproviderhomepage";
				} else {
					User admin = userService.fetchUser(username);
					session.setAttribute("admin", admin);
					List<HelpUserDto> userIds = helpDescriptionService.fetchUserIds("Pending");
					model.addAttribute("userIds", userIds);
					
					return "adminhomepage";
				}
			} else {
				model.addAttribute("invalidpassword", "invalid password");
				return "login";
			}
		} else {
			model.addAttribute("invalidusername", "invalid username");
			return "login";
		}

	}

	@RequestMapping("showregpage")
	public String showRegistrationPage(@ModelAttribute("user") User user) {
		user = new User();
		return "registration";
	}

	@RequestMapping("registration")
	public String userRegistration(@Valid @ModelAttribute("user") User user, BindingResult bindingResult, Model model) {
		System.out.println(user);
		String username = user.getUserName();
		String password = user.getPassword();
		String confirmPassword = user.getConfirmPassword();
		if (bindingResult.hasErrors()) {
			return "registration";
		} else if (userService.fetchUserName(username) != null) {
			model.addAttribute("alreadyExist", "Username already exist!");
			return "registration";
		} else if (userService.fetchEmail(user.getEmail()) != null) {
			model.addAttribute("EmailExist", "Email already exist!");
			return "registration";
		} else if (password.equals(confirmPassword)) {
			userService.saveUser(user);
			model.addAttribute("success", "submitted successfully!");
			return "message";
		} else {
			model.addAttribute("notMatch", "password and confirm password should be same!");
			return "registration";
		}
	}

	@ModelAttribute("securityQuestionList")
	public List<String> securityQuestion() {
		List<String> securityQuestionList = new ArrayList<String>();
		securityQuestionList.add("What was your childhood nickname?");
		securityQuestionList.add("What is your mother's maiden name?");
		securityQuestionList.add("What was your dream job? ");
		securityQuestionList.add("What is the name of your favorite childhood teacher? ");
		securityQuestionList.add("What is the middle name of your school's bestfriend?");
		return securityQuestionList;
	}

	/**
	 * this method is auto populating category values
	 * 
	 * @return
	 */
	@ModelAttribute("categoryList")
	public List<String> category() {
		List<String> categoryList = new ArrayList<String>();
		categoryList.add("General");
		categoryList.add("OBC");
		categoryList.add("SC/ST");
		categoryList.add("others");
		return categoryList;
	}

	/**
	 * 
	 * @param user
	 * @param request
	 * @return
	 */

	@RequestMapping("/logout")
	public String userLogout(@ModelAttribute("user") User user, HttpServletRequest request) {
		try {
			session = request.getSession();
			User student = (User) session.getAttribute("student");
			User scholarshipprovider = (User) session.getAttribute("scholarshipprovider");
			User admin = (User) session.getAttribute("admin");
			if (student != null || scholarshipprovider != null || admin != null) {
				session.removeAttribute("student");
				session.removeAttribute("scholarshipprovider");
				session.removeAttribute("admin");
				System.out.println(student + " " + scholarshipprovider + " " + admin);
				session.invalidate();

				System.out.println(session);
				return "logout";
			} else {
				session.invalidate();
				return "logout";
			}
		} catch (java.lang.IllegalStateException e) {
			session.invalidate();
			return "logout";
		}

	}

	@RequestMapping("/forgetpassword")
	public String forgotPassword(@ModelAttribute("user") User user) {
		user = new User();
		System.out.println(user);
		return "forgotpassword";
	}

	@RequestMapping("/entersecurityans")
	public String enterUserNameAndSecurityAnswer(@ModelAttribute("user") User user, BindingResult bindingResult,
			Model model) {
		System.out.println("esauser:" + user);
		String userName = user.getUserName();
		String securityAns = user.getSecurityAns();
		String securityAnswer = userService.fetchSecurityAns(userName);
		String securityQue = user.getSecurityQues();
		String securityQuestion = userService.fetchSecurityQue(userName);
		if (bindingResult.hasErrors()) {
			System.out.println(bindingResult.getErrorCount());
			return "forgotpassword";
		} else if (userService.fetchUserName(userName) != null) {
			if (securityAnswer.equals(securityAns) && securityQuestion.equals(securityQue)) {
				model.addAttribute(user);
				return "changepassword";
			} else {
				model.addAttribute("wrongSecurityAns", "Wrong Security Answer");
				return "forgotpassword";
			}

		} else {

			model.addAttribute("invalidusername", "invalid username");
			return "forgotpassword";
		}
	}

	@RequestMapping("/updatepassword")
	public String updatePassword(@ModelAttribute("user") User user, BindingResult bindingResult, Model model) {
		System.out.println("upuser:" + user);
		String password = user.getPassword();
		String confirmPassword = user.getConfirmPassword();
		if (bindingResult.hasErrors()) {
			return "changepassword";
		}

		else if (password.equals(confirmPassword)) {
			System.out.println("hello:" + user.getUserName());
			userService.updatePassword(password, user.getUserName());
			model.addAttribute("success", "changed successfully!");
			return "message";
		} else {
			model.addAttribute("notMatch", "password and confirm password should be same!");
			return "changepassword";
		}

	}

	@RequestMapping("/forgetusername")
	public String forgotUserName(@ModelAttribute("user") User user) {
		user = new User();
		System.out.println(user);
		return "forgotusername";
	}

	@RequestMapping("/enteremail")
	public String enterEmailAndSecurityAnswer(@ModelAttribute("user") User user, BindingResult bindingResult,
			Model model) {
		System.out.println("eeuser:" + user);
		String email = user.getEmail();

		if (bindingResult.hasErrors()) {
			System.out.println("having errors in forget username");
			return "forgotusername";
		} else if (userService.fetchEmail(email) != null) {
			String securityAns = user.getSecurityAns();
			String securityAnswer = userService.fetchSecurityAnsByEmail(email);
			String securityQue = user.getSecurityQues();
			String securityQuestion = userService.fetchSecurityQueByEmail(email);
			if (securityAnswer.equals(securityAns) && securityQuestion.equals(securityQue)) {
				model.addAttribute("username", userService.fetchUserNameOnEmail(email));
				return "viewusername";
			} else {
				model.addAttribute("wrongSecurityAns", "Wrong Security Answer");
				return "forgotusername";
			}

		} else {

			model.addAttribute("invalidemail", "invalid email");
			return "forgotusername";
		}
	}
}
