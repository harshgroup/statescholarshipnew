package com.cognizant.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cognizant.model.User;
import com.cognizant.service.UserService;

@Controller
public class UserController {
	@Autowired
	UserService userService;
	HttpSession session;

	@RequestMapping("/login")
	public String showLogin(@ModelAttribute("user") User user) {

		user = new User();
		System.out.print(user);
		return "login";
	}

	@RequestMapping("/homepage")
	public String showHomePage(@ModelAttribute("user") User user, HttpServletRequest request, Model model) {
		String username = user.getUserName();
		String password = user.getPassword();
		if (userService.fetchUserName(username)!=null) {
			if (userService.fetchPassowrd(username).equals(password)) {
				session = request.getSession();
				String role = userService.fetchRole(username);
				
				if (role.equals("student")) {
					User student = userService.fetchUser(username);
					session.setAttribute("student", student);
					return "studenthomepage";
				} else if (role.equals("scholarshipprovider")) {
					User scholarshipprovider = userService.fetchUser(username);
					session.setAttribute("scholarshipprovider", scholarshipprovider);
					return "scholarshipproviderhomepage";
				} else {
					User admin = userService.fetchUser(username);
					session.setAttribute("admin", admin);
					return "adminhomepage";
				}
			} else {
				model.addAttribute("invalidpassword", "invalid password");
				return "login";
			}
		} else {
			model.addAttribute("invalidusername", "invalid username");
			return "login";
		}

	}

	@RequestMapping("showregpage")
	public String showRegistrationPage(@ModelAttribute("user") User user) {
		user = new User();
		return "registration";
	}

	@RequestMapping("registration")
	public String userRegistration(@Valid @ModelAttribute("user") User user, BindingResult bindingResult, Model model) {
		System.out.println(user);
		String username = user.getUserName();
		String password = user.getPassword();
		String confirmPassword = user.getConfirmPassword();
		if (bindingResult.hasErrors()) {
			return "registration";
		} else if (userService.fetchUserName(username)!=null) {
			model.addAttribute("alreadyExist", "Username already exist!");
			return "registration";
		} else if (password.equals(confirmPassword)) {
			userService.saveUser(user);
			model.addAttribute("success", "submitted successfully!");
			return "login";
		} else {
			model.addAttribute("notMatch", "password and confirm password should be same!");
			return "registration";
		}
	}

	@ModelAttribute("securityQuestionList")
	public List<String> securityQuestion() {
		List<String> securityQuestionList = new ArrayList<String>();
		securityQuestionList.add("What was your childhood nickname?");
		securityQuestionList.add("What is your mother's maiden name?");
		securityQuestionList.add("What was your dream job? ");
		securityQuestionList.add("What is the name of your favorite childhood teacher? ");
		securityQuestionList.add("What is the middle name of your school's bestfriend?");
		return securityQuestionList;
	}

	@ModelAttribute("categoryList")
	public List<String> category() {
		List<String> categoryList = new ArrayList<String>();
		categoryList.add("General");
		categoryList.add("OBC");
		categoryList.add("SC/ST");
		categoryList.add("others");
		return categoryList;
	}

	@RequestMapping("/logout")
	public String userLogout(@ModelAttribute("user") User user) {
		try {
			session.invalidate();
		} catch (java.lang.IllegalStateException e) {
			return "logout";
		}
		return "logout";
	}
}
