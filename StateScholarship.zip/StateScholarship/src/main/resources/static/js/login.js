function validateForm() {
	var userName = document.forms["myForm"]["userName"].value;
	var password = document.forms["myForm"]["password"].value;
	if (userName == "" && password == "") {
		alert("Username and password can not be empty!");
		return false;
	} else if (userName == "") {
		alert("Username can not be empty!");
		return false;
	} else if (password == "") {
		alert("Password can not be empty!");
		return false;
	}

}