function validateForm() {
	var userName = document.forms["myForm"]["userName"].value;
	var password = document.forms["myForm"]["password"].value;
	if (userName == "" && password == "") {
		alert("Username and password can not be empty!");
		return false;
	} else if (userName == "") {
		alert("Username can not be empty!");
		return false;
	} else if (password == "") {
		alert("Password can not be empty!");
		return false;
	}

}

function validatforgotusername() {
	var email = document.forms["myForm"]["email"].value;
	var securityAns = document.forms["myForm"]["securityAns"].value;
	if (email == "" && securityAns == "") {
		alert("email and security answer cannot be empty!");
		return false;
	} else if (email == "") {
		alert("Email cannot be empty!");
		return false;
	} else if (securityAns == "") {
		alert("Security answer cannot be empty");
		return false;
	}
}

function validatforgotpassword() {
	var userName = document.forms["myForm"]["userName"].value;
	var securityAns = document.forms["myForm"]["securityAns"].value;
	if (userName == "" && securityAns == "") {
		alert("Username and security answer cannot be empty!");
		return false;
	} else if (userName == "") {
		alert("Username cannot be empty!");
		return false;
	} else if (securityAns == "") {
		alert("Security answer cannot be empty");
		return false;
	}
}

function validatePassword() {
	var password = document.forms["myForm"]["password"].value;
	var ConfirmPassword = document.forms["myForm"]["confirmPassword"].value;
	if (password == "" && ConfirmPassword== "") {
		alert("password and confirm password cannot be empty!");
		return false;
	} else if (password == "") {
		alert("password cannot be empty!");
		return false;
	} else if (ConfirmPassword == "") {
		alert("confirm password cannot be empty");
		return false;
	}
}

function validateIssueDescription() {
	var description = document.forms["myForm"]["description"].value;
	if (description == "") {
		alert("Description cannot be empty!");
		return false;
	}
}

function validateSolutionDescription() {
	var description = document.forms["myForm"]["solution"].value;
	if (description == "") {
		alert("solution cannot be empty!");
		return false;
	}
}